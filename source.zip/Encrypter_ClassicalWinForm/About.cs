﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Encrypter_ClassicalWinForm
{
    public partial class About : Form
    {
        bool mousedown = false;
        Point mouseRelPos;

        public About()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            MainForm.loc = Location;
            MainForm.state = 1;
            Close();
        }

        private void About_VisibleChanged(object sender, EventArgs e)
        {
            Location = MainForm.loc;
        }

        private void Panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseRelPos = PointToClient(MousePosition);
            mousedown = true;
        }

        private void Panel1_MouseUp(object sender, MouseEventArgs e)
        {
            mousedown = false;
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (mousedown)
            {
                Location = new Point(MousePosition.X - mouseRelPos.X, MousePosition.Y - mouseRelPos.Y);
            }
        }


        private void Panel1_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, new Rectangle(0, 0, 395, 234),
                Color.CornflowerBlue, 1, ButtonBorderStyle.Solid,
                Color.CornflowerBlue, 1, ButtonBorderStyle.Solid,
                Color.CornflowerBlue, 1, ButtonBorderStyle.Solid,
                Color.CornflowerBlue, 1, ButtonBorderStyle.Solid);
        }

        private void About_Load(object sender, EventArgs e)
        {
            switch (MainForm.language)
            {
                case (0):
                    label2.Text = "本软件由 @Stehsaer 制作。";
                    label1.Text = "关于本软件";
                    label3.Text = "联系方式：Email：";
                    label4.Text = "有bug记得在Github上告诉我鸭~";
                    label6.Text = "如果有对于这款软件的改进想法，也请用电子邮件或者在Github上联系我吧";
                    break;
                case (1):
                    label2.Text = "The program is made by @Stehsaer.";
                    label1.Text = "About File Encrypter";
                    label3.Text = "Contact me via Email:";
                    label4.Text = "If there's any bugs or issues, please report on Github";
                    label6.Text = "If you like File Encrypter and you have some ideas for this, consider helping me on Github, thank you.";
                    break;
            }
            label5.Text = MainForm.version;
        }


    }
}
