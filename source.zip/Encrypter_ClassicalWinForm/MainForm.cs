﻿/* Copyright 2019. Stehsaer ( Jason Liu) */
/* Contact me via email: Stehsaer@outlook.com */

using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Encrypter_ClassicalWinForm
{

    public partial class MainForm : Form
    {
        public static int state = 0;
        public static Point loc;
        string filename;
        string savefolder;

        public const string version = "0.9";

        Color maincolor = Color.CornflowerBlue;
        const string website = "https://github.com/Stehsaer/File-Encypter/releases/latest";

        public static int language = 0;

        byte[] data;

        string status = "wait";
        bool mousedown = false;
        Point mouseRelPos;

        double progress;
        string labelText;

        string password;
        int tickstarted = 1;

        long length;

        public MainForm(string[] args)
        {
            if (args.Length == 0)
            {
                filename = null;
            }
            else
            {
                filename = args[0];
            }
            InitializeComponent();
        }

        private void Form1_Load(object sender, System.EventArgs e)
        {
            ProgressLabel.Text = "";
            if (filename != null)
            {
                OpenFileText.Text = filename;
                SaveFileText.Text = Path.GetDirectoryName(filename);
            }
            switch (Thread.CurrentThread.CurrentCulture.Name)
            {
                case ("zh-CN"):
                    language = 0;
                    zh_cn_item.Checked = true;
                    en_us_item.Checked = false;
                    break;
                case ("en-US"):
                    language = 1;
                    zh_cn_item.Checked = false;
                    en_us_item.Checked = true;
                    break;
            }
            ChangeLanguage();

            if (Environment.Is64BitOperatingSystem & !Environment.Is64BitProcess)
            {
                DialogResult result = DialogResult.None;
                switch (language)
                {
                    case (0):
                        result = MessageBox.Show("当前系统为 64位 或 x64 系统，本程序为32位程序，建议使用64位版本 \r\n 即将打开地址：https://github.com/Stehsaer/File-Encypter/releases/latest \r\n 按确定打开发布页，按取消继续使用", "64位系统使用32位程序", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        break;
                    case (1):
                        result = MessageBox.Show("The OS you are using currently is 64-bit or x64, the program is 32-bit and designed for 32-bit OS, using 64-bit or x64 version is strongly recommanded \r\n Opening Downloading Website:https://github.com/Stehsaer/File-Encypter/releases/latest \r\n Press OK to open the page; Press Cancel to Continue using", "Using 32-bit app on 64-bit OS", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        break;
                }
                if (result == DialogResult.OK)
                {
                    Process.Start(website );
                }
            }
        }

        private void Timer1_Tick(object sender, System.EventArgs e)
        {
            switch (language)
            {
                case (0):
                    switch (status)
                    {
                        case ("wait"):
                            labelText = "准备就绪";
                            maincolor = Color.CornflowerBlue;
                            progress = 0;
                            break;
                        case ("rf"):
                            labelText = "读取文件中 " + ShowSize((ulong)(new FileInfo(filename).Length * progress)) + " / " + ShowSize((ulong)new FileInfo(filename).Length) + "   " + ShowSize((ulong)((double)new FileInfo(filename).Length * progress / (double)(System.Environment.TickCount - tickstarted) * 1000d)) + "/s  " + progress.ToString("0.0%");
                            break;
                        case ("pf"):
                            labelText = "文件重排序中 " + progress.ToString("0.0%");
                            break;
                        case ("ef"):
                            labelText = "加密文件中   " + ShowSize((ulong)(data.Length * progress)) + " / " + ShowSize((ulong)data.Length) + "   " + ShowSize((ulong)((double)data.Length * progress / (double)(System.Environment.TickCount - tickstarted) * 1000d)) + "/s  " + progress.ToString("0.0%");
                            break;
                        case ("df"):
                            labelText = "解密文件中   " + ShowSize((ulong)(data.Length * progress)) + " / " + ShowSize((ulong)data.Length) + "   " + ShowSize((ulong)((double)data.Length * progress / (double)(System.Environment.TickCount - tickstarted) * 1000d)) + "/s  " + progress.ToString("0.0%");
                            break;
                        case ("wf"):
                            labelText = "写入文件中   " + ShowSize((ulong)(length * progress)) + " / " + ShowSize((ulong)length) + "   " + ShowSize((ulong)((double)length * progress / (double)(System.Environment.TickCount - tickstarted) * 1000d)) + "/s  " + progress.ToString("0.0%");
                            break;
                        case ("ff"):
                            labelText = "合并安全信息中   " + progress.ToString("0.0%");
                            break;
                        case ("hf"):
                            labelText = "哈希计算中 ";
                            break;
                        case ("sf"):
                            labelText = "拆分信息中     " + progress.ToString("0.0%");
                            break;
                    }
                    break;

                case (1):
                    switch (status)
                    {
                        case ("wait"):
                            labelText = "Stand by";
                            maincolor = Color.CornflowerBlue;
                            progress = 0;
                            break;
                        case ("rf"):
                            labelText = "Reading File " + ShowSize((ulong)(new FileInfo(filename).Length * progress)) + " / " + ShowSize((ulong)new FileInfo(filename).Length) + "   " + ShowSize((ulong)((double)new FileInfo(filename).Length * progress / (double)(System.Environment.TickCount - tickstarted) * 1000d)) + "/s  " + progress.ToString("0.0%");
                            break;
                        case ("pf"):
                            labelText = "Sorting Data " + progress.ToString("0.0%");
                            break;
                        case ("ef"):
                            labelText = "Encrypting " + ShowSize((ulong)(data.Length * progress)) + " / " + ShowSize((ulong)data.Length) + "   " + ShowSize((ulong)((double)data.Length * progress / (double)(System.Environment.TickCount - tickstarted) * 1000d)) + "/s  " + progress.ToString("0.0%");
                            break;
                        case ("df"):
                            labelText = "Decrypting " + ShowSize((ulong)(data.Length * progress)) + " / " + ShowSize((ulong)data.Length) + "   " + ShowSize((ulong)((double)data.Length * progress / (double)(System.Environment.TickCount - tickstarted) * 1000d)) + "/s  " + progress.ToString("0.0%");
                            break;
                        case ("wf"):
                            labelText = "Writing File " + ShowSize((ulong)(length * progress)) + " / " + ShowSize((ulong)length) + "   " + ShowSize((ulong)((double)length * progress / (double)(System.Environment.TickCount - tickstarted) * 1000d)) + "/s  " + progress.ToString("0.0%");
                            break;
                        case ("ff"):
                            labelText = "Merging Data " + progress.ToString("0.0%");
                            break;
                        case ("hf"):
                            labelText = "Computing Hash ";
                            break;
                        case ("sf"):
                            labelText = "Seperating Data " + progress.ToString("0.0%");
                            break;
                    }
                    break;
            }
            progressbar.Width = progressbar.Width + ((int)(393d * progress) - progressbar.Width) / 3;
            ProgressLabel.Text = labelText;
            progressbar.BackColor = maincolor;
            if (mousedown)
            {
                Location = new Point(MousePosition.X - mouseRelPos.X, MousePosition.Y - mouseRelPos.Y);
            }
            if (state == 1)
            {
                Show();
                state = 0;
                Location = loc;
            }
        }

        public static string ShowSize(ulong byte_count)
        {
            if (byte_count <= 1024)
            {
                return byte_count + "B";
            }
            if (byte_count > 1024 & byte_count <= 1024 * 1024)
            {
                return ((double)byte_count / 1024d).ToString("0.00") + "KiB";
            }
            if (byte_count > 1048576 & byte_count <= 1073741824)
            {
                return ((double)byte_count / 1048576d).ToString("0.00") + "MiB";
            }
            if (byte_count > 1073741824)
            {
                return ((double)byte_count / 1073741824d).ToString("0.00") + "GiB";
            }
            return "Error";
        }

        private void OpenFileSelect_Click(object sender, EventArgs e)
        {
            openFile.ShowDialog();
            OpenFileText.Text = openFile.FileName;
        }

        private void SaveFileSelect_Click(object sender, EventArgs e)
        {
            if (File.Exists(OpenFileText.Text))
            {
                if (new FileInfo(OpenFileText.Text).Extension == ".enc")
                {
                    if (new FileInfo(OpenFileText.Text).Extension.StartsWith("."))
                    {
                        switch (language)
                        {
                            case (0):
                                saveFile.Filter = "所有文件|*.*";
                                break;

                            case (1):
                                saveFile.Filter = "All Files|*.*";
                                break;
                        }
                    }
                    else
                    {

                        switch (language)
                        {
                            case (0):
                                saveFile.Filter = "所有文件|*.*"; break;

                            case (1):
                                saveFile.Filter = "All Files|*.*"; break;
                        }
                    }
                }
                else
                {
                    switch (language)
                    {
                        case (0):
                            saveFile.Filter = "加密文件|*.enc"; break;

                        case (1):
                            saveFile.Filter = "Encrypter File|*.enc"; break;
                    }
                }
            }
            else
            {
                switch (language)
                {
                    case (0):
                        saveFile.Filter = "所有文件|*.*"; break;

                    case (1):
                        saveFile.Filter = "All Files|*.*"; break;
                }
            }
            saveFile.ShowDialog();
            SaveFileText.Text = saveFile.FileName;
        }

        private void EncryptButton_Click(object sender, EventArgs e)
        {
            filename = OpenFileText.Text;
            savefolder = SaveFileText.Text;
            password = PasswordBox.Text;
            if (File.Exists(filename))
            {
                if (password.Length == 8)
                {
                    if (new FileInfo(filename).Length <= 2147483647)
                    {
                        if (Directory.Exists(Path.GetDirectoryName(savefolder)))
                        {
                            EncB.RunWorkerAsync();
                            EncryptButton.Enabled = false;
                            DecryptButton.Enabled = false;
                            OpenFileText.ReadOnly = true;
                            SaveFileText.ReadOnly = true;
                            PasswordBox.ReadOnly = true;
                        }
                        else
                        {
                            switch (language)
                            {
                                case (0):
                                    MessageBox.Show("无效文件保存路径", "路径无效", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                                case (1):
                                    MessageBox.Show("Invalid file saving directory", "Invalid Directory", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                            }
                        }
                    }
                    else
                    {
                        maincolor = Color.Tomato;

                        switch (language)
                        {
                            case (0):
                                MessageBox.Show("大小超过 2GiB 的文件不受支持（或许在后续版本会支持）", "不支持!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            case (1):
                                MessageBox.Show("Processing file over 2GiB isn't supported ( Maybe in later version it can be achieved)", "Not Supported", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                        }
                    }
                }
                else
                {
                    maincolor = Color.Tomato;
                    switch (language)
                    {
                        case (0):
                            MessageBox.Show("密码位数必须为8", "错误!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                        case (1):
                            MessageBox.Show("Password Length should be 8", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                    }
                }
            }
            else
            {
                maincolor = Color.Tomato;
                switch (language)
                {
                    case (0):
                        MessageBox.Show("文件不存在", "错误!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case (1):
                        MessageBox.Show("File does not exists", "Oh no!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
        }

        private void EncB_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            try
            {
                bool flag = true;
                status = "rf";
                tickstarted = Environment.TickCount;
                data = new byte[new FileInfo(filename).Length];
                FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read);
                for (long i = 0; i < data.Length; i++)
                {
                    data[i] = (byte)fs.ReadByte();
                    progress = (double)i / (double)data.Length;
                }

                status = "hf";
                byte[] hash;
                if (data.Length <= 8192)
                {
                    hash = SHA256.Create().ComputeHash(data, 0, data.Length);
                }
                else
                {
                    hash = SHA256.Create().ComputeHash(data, 0, 8192);
                }
                byte[] finalBlock = EncryptByte(hash, Encoding.UTF8.GetBytes(password), Encoding.UTF8.GetBytes(password));
                int len = (int)finalBlock.Length;
                byte[] datatemp = new byte[data.Length + 4 + len];
                byte[] lenbyte = BitConverter.GetBytes(len);
                uint bytecount = 0;


                status = "ef";
                tickstarted = Environment.TickCount;
                for (int i = 0; i < data.Length; i++)
                {
                    if (i % 2 == 0)
                    {
                        data[i] = (byte)((data[i] + hash[i % hash.Length]) % 256);
                    }
                    else
                    {
                        data[i] = (byte)((data[i] + 256 - hash[i % hash.Length]) % 256);
                    }
                    progress = (double)i / (double)data.Length;
                }
                string name;
                name = savefolder;

                status = "ff";
                tickstarted = Environment.TickCount;
                foreach (byte bt in lenbyte)
                {
                    datatemp[bytecount] = bt;
                    bytecount++;
                    progress = (double)bytecount / (double)datatemp.Length;
                }
                foreach (byte bt in data)
                {
                    datatemp[bytecount] = bt;
                    bytecount++;
                    progress = (double)bytecount / (double)datatemp.Length;
                }
                foreach (byte bt in finalBlock)
                {
                    datatemp[bytecount] = bt;
                    bytecount++;
                    progress = (double)bytecount / (double)datatemp.Length;
                }

                data = datatemp;
                status = "pf";
                for (int i = 0; i < data.Length / 2; i++)
                {
                    byte temp;
                    temp = data[i];
                    data[i] = data[data.Length - 1 - i];
                    data[data.Length - 1 - i] = temp;
                    progress = (double)i / (double)data.Length * 2;
                }
                datatemp = new byte[0];
                datatemp = null;
                GC.Collect();
                GC.Collect();

                if (flag)
                {
                    status = "wf";
                    if (File.Exists(name))
                    {
                        name = savefolder;
                        try
                        {
                            File.Create(name).Close();
                        }
                        catch (UnauthorizedAccessException)
                        {
                            maincolor = Color.Tomato;
                            switch (language)
                            {
                                case (0):
                                    MessageBox.Show("缺少权限访问文件，请尝试以管理员身份运行程序", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                                case (1):
                                    MessageBox.Show("Requires special access to make changes to the file or file system, please try running the program as Admin", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                            }
                            e.Cancel = true;
                        }
                        catch (DirectoryNotFoundException)
                        {
                            MessageBox.Show("Error0");
                        }
                    }
                    else
                    {
                        try
                        {
                            File.Create(name).Close();
                        }
                        catch (UnauthorizedAccessException)
                        {
                            maincolor = Color.Tomato;
                            switch (language)
                            {
                                case (0):
                                    MessageBox.Show("缺少权限访问文件，请尝试以管理员身份运行程序", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                                case (1):
                                    MessageBox.Show("Requires special access to make changes to the file or file system, please try running the program as Admin", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                            }
                            e.Cancel = true;
                        }
                        catch (DirectoryNotFoundException)
                        {
                            MessageBox.Show("Error1");
                        }
                    }
                    try
                    {
                        length = data.Length;
                        tickstarted = Environment.TickCount;
                        FileStream filewrite = new FileStream(name, FileMode.Open, FileAccess.Write);
                        for (long i = 0; i < data.Length; i++)
                        {
                            filewrite.WriteByte(data[i]);
                            progress = (double)i / (double)data.Length;
                        }
                    }
                    catch (UnauthorizedAccessException)
                    {
                        maincolor = Color.Tomato;
                        switch (language)
                        {
                            case (0):
                                MessageBox.Show("缺少权限访问文件，请尝试以管理员身份运行程序", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            case (1):
                                MessageBox.Show("Requires special access to make changes to the file or file system, please try running the program as Admin", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                        }
                        e.Cancel = true;
                    }
                    catch (DirectoryNotFoundException)
                    {
                        MessageBox.Show("Error2");
                    }
                }
            }
            catch (OutOfMemoryException)
            {
                switch (language)
                {
                    case (0):
                        MessageBox.Show("系统内存不足，无法继续执行。\r\n 可能原因：\r\n 1.使用32位版本的该程序，32位系统可访问的内存较小，可能无法胜任 \r\n 2.电脑可用内存过小，一般来说内存要在4GiB以上才能正常处理大文件", "内存不足", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case (1):
                        MessageBox.Show("More memory space is required to run \r\n Possible Reasons:\r\n 1.You're using x86 or 32-bit version of File Encrypter, less memory can be accessed by a 32-bit program, the issue happens when you are trying to process a large file \r\n 2. Maybe there's just not enough Physical Memory on your computer, normally, it needs 4GiB of memory to 'run free' ", "Not Enough Memory Space", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
            status = "wait";
        }

        private void DecB_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            try
            {
                bool flag = true;
                status = "rf";
                tickstarted = Environment.TickCount;
                data = new byte[new FileInfo(filename).Length];
                FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read);
                for (long i = 0; i < data.Length; i++)
                {
                    data[i] = (byte)fs.ReadByte();
                    progress = (double)i / (double)data.Length;
                }

                status = "pf";
                for (int i = 0; i < data.Length / 2; i++)
                {
                    byte temp;
                    temp = data[i];
                    data[i] = data[data.Length - 1 - i];
                    data[data.Length - 1 - i] = temp;
                    progress = (double)i / (double)data.Length * 2;
                }

                status = "sf";
                tickstarted = Environment.TickCount;
                byte[] finalBlock = new byte[0];
                byte[] len_byte = new byte[4];
                int len = 0;
                byte[] data_temp;
                try
                {

                    for (uint i = 0; i < 4; i++)
                    {
                        len_byte[i] = data[i];
                        progress = (double)i / (double)data.Length;
                    }
                    len = BitConverter.ToInt32(len_byte, 0);
                    finalBlock = new byte[len];
                    data_temp = new byte[data.Length - len - 4];
                    for (uint i = 4; i < data.Length - len; i++)
                    {
                        data_temp[i - 4] = data[i];
                        progress = (double)i / (double)data.Length;
                    }
                    for (int i = data.Length - len; i < data.Length; i++)
                    {
                        finalBlock[i - (data.Length - len)] = data[i];
                        progress = (double)i / (double)data.Length;
                    }
                    data = data_temp;

                }
                catch (OverflowException)
                {
                    maincolor = Color.Tomato;

                    switch (language)
                    {
                        case (0):
                            MessageBox.Show("源文件已损坏", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                        case (1):
                            MessageBox.Show("Source File has been damaged", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                    }
                    flag = false;

                }
                data_temp = new byte[0];
                data_temp = null;
                GC.Collect();
                GC.Collect();

                byte[] hash = DecryptByte(finalBlock, Encoding.UTF8.GetBytes(password), Encoding.UTF8.GetBytes(password));
                if (flag)
                {
                    if (hash == null)
                    {
                        maincolor = Color.Tomato;
                        switch (language)
                        {
                            case (0):
                                MessageBox.Show("密码错误", "错误!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            case (1):
                                MessageBox.Show("Wrong Password", "Try again", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                        }
                        flag = false;
                    }
                }
                finalBlock = null;
                GC.Collect();

                string name;

                if (flag)
                {
                    status = "df";
                    tickstarted = Environment.TickCount;

                    for (uint i = 0; i < data.Length; i++)
                    {
                        if (i % 2 == 0)
                        {
                            data[i] = (byte)((data[i] + 256 - hash[i % hash.Length]) % 256);
                        }
                        else
                        {
                            data[i] = (byte)((data[i] + hash[i % hash.Length]) % 256);
                        }

                        progress = (double)i / (double)data.Length;
                    }

                    name = savefolder + "/" + Path.GetFileNameWithoutExtension(filename);
                }

                if (flag)
                {
                    status = "hf";
                    bool flag1 = true;
                    byte[] hash_original;
                    if (data.Length <= 8192)
                    {
                        hash_original = SHA256.Create().ComputeHash(data, 0, data.Length);
                    }
                    else
                    {
                        hash_original = SHA256.Create().ComputeHash(data, 0, 8192);
                    }
                    for (uint i = 0; i < hash.Length; i++)
                    {
                        if (hash[i] != hash_original[i])
                        {
                            flag1 = false;
                            break;
                        }
                    }

                    if (!flag1)
                    {
                        maincolor = Color.Tomato;
                        switch (language)
                        {
                            case (0):
                                MessageBox.Show("源文件已损坏", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            case (1):
                                MessageBox.Show("Source File has been damaged", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                        }
                        flag = false;
                    }
                }

                if (flag)
                {
                    status = "wf";
                    tickstarted = Environment.TickCount;
                    name = savefolder;
                    if (File.Exists(name))
                    {
                        name = savefolder;
                        try
                        {
                            File.Create(name).Close();
                        }
                        catch (UnauthorizedAccessException)
                        {
                            maincolor = Color.Tomato;
                            switch (language)
                            {
                                case (0):
                                    MessageBox.Show("缺少权限访问文件，请尝试以管理员身份运行程序", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                                case (1):
                                    MessageBox.Show("Requires special access to make changes to the file or file system, please try running the program as Admin", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                            }
                            flag = false;
                        }
                        catch (DirectoryNotFoundException)
                        {
                            MessageBox.Show("Error3");
                        }
                    }
                    else
                    {
                        try
                        {
                            File.Create(name).Close();
                        }
                        catch (UnauthorizedAccessException)
                        {
                            maincolor = Color.Tomato;
                            switch (language)
                            {
                                case (0):
                                    MessageBox.Show("缺少权限访问文件，请尝试以管理员身份运行程序", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                                case (1):
                                    MessageBox.Show("Requires special access to make changes to the file or file system, please try running the program as Admin", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                            }
                        }
                        catch (DirectoryNotFoundException)
                        {
                            MessageBox.Show("Error4");
                        }
                    }
                    try
                    {
                        FileStream filewrite = new FileStream(name, FileMode.Open, FileAccess.Write);
                        length = data.Length;
                        for (long i = 0; i < data.Length; i++)
                        {
                            filewrite.WriteByte(data[i]);
                            progress = (double)i / (double)data.Length;
                        }
                    }
                    catch (UnauthorizedAccessException)
                    {
                        maincolor = Color.Tomato;
                        switch (language)
                        {
                            case (0):
                                MessageBox.Show("缺少权限访问文件，请尝试以管理员身份运行程序 :(", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            case (1):
                                MessageBox.Show("Requires special access to make changes to the file or file system, please try running the program as Admin :(", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                        }
                        flag = false;
                    }
                    catch (DirectoryNotFoundException)
                    {
                        MessageBox.Show("Error");
                    }
                }
            }
            catch (OutOfMemoryException)
            {
                switch (language)
                {
                    case (0):
                        MessageBox.Show("系统内存不足，无法继续执行。\r\n 可能原因：\r\n 1.使用32位版本的该程序，32位系统可访问的内存较小，可能无法胜任 \r\n 2.电脑可用内存过小，一般来说内存要在4GiB以上才能正常处理大文件", "内存不足", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case (1):
                        MessageBox.Show("More memory space is required to run \r\n Possible Reasons:\r\n 1.You're using x86 or 32-bit version of File Encrypter, less memory can be accessed by a 32-bit program, the issue happens when you are trying to process a large file \r\n 2. Maybe there's just not enough Physical Memory on your computer, normally, it needs 4GiB of memory to 'run free' ", "Not Enough Memory Space", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }

            status = "wait";
        }

        private void DecyrptButton_Click(object sender, EventArgs e)
        {
            filename = OpenFileText.Text;
            savefolder = SaveFileText.Text;
            password = PasswordBox.Text;
            if (File.Exists(filename))
            {

                if (new FileInfo(filename).Extension == ".enc")
                {
                    if (password.Length == 8)
                    {
                        if (new FileInfo(filename).Length <= 2147483647)
                        {
                            if (Directory.Exists(Path.GetDirectoryName(savefolder)))
                            {
                                DecB.RunWorkerAsync();
                                EncryptButton.Enabled = false;
                                DecryptButton.Enabled = false;
                                OpenFileText.ReadOnly = true;
                                SaveFileText.ReadOnly = true;
                                PasswordBox.ReadOnly = true;
                            }
                            else
                            {
                                switch (language)
                                {
                                    case (0):
                                        MessageBox.Show("无效文件保存路径", "路径无效", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        break;
                                    case (1):
                                        MessageBox.Show("Invalid file saving directory", "Invalid Directory", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        break;
                                }
                            }
                        }
                        else
                        {
                            maincolor = Color.Tomato;
                            switch (language)
                            {
                                case (0):
                                    MessageBox.Show("大小超过 2GiB 的文件不受支持（或许在后续版本会支持）", "不支持!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                                case (1):
                                    MessageBox.Show("Processing file over 2GiB isn't supported ( Maybe in later version it can be achieved)", "Not Supported", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                            }
                        }
                    }
                    else
                    {
                        maincolor = Color.Tomato;
                        switch (language)
                        {
                            case (0):
                                MessageBox.Show("密码位数必须为8", "错误!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            case (1):
                                MessageBox.Show("Password Length should be 8", "Error :(", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                        }
                    }
                }
                else
                {
                    maincolor = Color.Tomato;

                    switch (language)
                    {
                        case (0):
                            MessageBox.Show("这个后缀感觉不是用来解密的啊 :(", "错误!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                        case (1):
                            MessageBox.Show("It doesn't feel like it can be decrypted due to its extension... :(", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                    }
                }

            }
            else
            {
                maincolor = Color.Tomato;
                switch (language)
                {
                    case (0):
                        MessageBox.Show("文件不存在", "错误!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case (1):
                        MessageBox.Show("File does not exists", "Oh no!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
        }

        void Finish()
        {

            switch (language)
            {
                case (0):
                    MessageBox.Show("一切程序完成", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                case (1):
                    MessageBox.Show("All requested processes are done", "Hey there", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
            }
            EncryptButton.Enabled = true;
            DecryptButton.Enabled = true;
            OpenFileText.ReadOnly = false;
            SaveFileText.ReadOnly = false;
            PasswordBox.ReadOnly = false;
            status = "wait";
        }

        private void EncB_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            data = null;
            GC.Collect();
            Finish();
        }

        private void DecB_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            data = null;
            GC.Collect();
            Finish();
        }

        public static byte[] EncryptByte(byte[] sourceData, byte[] key, byte[] iv)
        {
            try
            {
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();

                using (MemoryStream ms = new MemoryStream())
                {
                    try
                    {
                        using (CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(key, iv), CryptoStreamMode.Write))
                        {
                            cs.Write(sourceData, 0, sourceData.Length);

                            cs.FlushFinalBlock();
                        }

                        return ms.ToArray();
                    }
                    catch
                    {
                        return null;
                    }
                }
            }
            catch { }
            return null;
        }

        public static byte[] DecryptByte(byte[] encryptedByte, byte[] key, byte[] iv)
        {

            DESCryptoServiceProvider des = new DESCryptoServiceProvider();

            using (MemoryStream ms = new MemoryStream())
            {
                try
                {
                    using (CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(key, iv), CryptoStreamMode.Write))
                    {
                        cs.Write(encryptedByte, 0, encryptedByte.Length);

                        cs.FlushFinalBlock();
                    }

                    return ms.ToArray();
                }
                catch
                {
                    return null;
                }
            }
        }

        private void OpenFileText_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files.Length == 1)
            {
                OpenFileText.Text = files[0];
            }
            else
            {
                switch (language)
                {
                    case (0):
                        MessageBox.Show("不支持多文件加/解密", "不支持", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case (1):
                        MessageBox.Show("Multi-file processing isn't yet supported \r Consider giving some help on my github repos", "Not supported", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
        }

        private void OpenFileText_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }

        private void Label3_MouseEnter(object sender, EventArgs e)
        {
            PasswordBox.UseSystemPasswordChar = false;
        }

        private void Label3_MouseLeave(object sender, EventArgs e)
        {
            PasswordBox.UseSystemPasswordChar = true;
        }

        public static string ShowTime(ulong ms)
        {
            string returnstr;
            returnstr = ((ms / 1000) % 60).ToString() + "s";
            if (ms > 60000)
            {
                returnstr = (ms / 60000).ToString() + "min" + returnstr;
            }

            return returnstr;
        }

        private void Panel4_MouseDown(object sender, MouseEventArgs e)
        {
            mouseRelPos = PointToClient(MousePosition);
            mousedown = true;
        }

        private void Panel4_MouseUp(object sender, MouseEventArgs e)
        {
            mousedown = false;
        }

        private void NotifyIcon1_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                WindowState = FormWindowState.Normal;
            }
            else
            {
                WindowState = FormWindowState.Minimized;
            }
        }

        private void NotifyIcon1_BalloonTipClicked(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Normal;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            notifyIcon1.Dispose();
            Application.Exit();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void AboutButton_Click(object sender, EventArgs e)
        {
            Hide();
            GC.Collect();
            loc = Location;
            new About().Show();
        }

        private void Panel3_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, new Rectangle(0, 0, 395, 234),
                maincolor, 1, ButtonBorderStyle.Solid,
                maincolor, 0, ButtonBorderStyle.Solid,
                maincolor, 1, ButtonBorderStyle.Solid,
                maincolor, 1, ButtonBorderStyle.Solid);
        }

        private void Panel4_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, new Rectangle(0, 0, panel4.Width, panel4.Height),
                maincolor, 1, ButtonBorderStyle.Solid,
                maincolor, 1, ButtonBorderStyle.Solid,
                maincolor, 1, ButtonBorderStyle.Solid,
                maincolor, 0, ButtonBorderStyle.Solid);
        }

        private void Label5_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, new Rectangle(0, 0, panel4.Width, panel4.Height),
                maincolor, 1, ButtonBorderStyle.Solid,
                maincolor, 1, ButtonBorderStyle.Solid,
                maincolor, 0, ButtonBorderStyle.Solid,
                maincolor, 0, ButtonBorderStyle.Solid);
        }

        private void ChangeLanguage()
        {
            if (Environment.Is64BitProcess)
            {
                switch (language)
                {
                    case (0):
                        Text = "文件加密器";
                        Title.Text = "文件加密器 " + version + " by Stehsaer x64";
                        EncryptButton.Text = "加密";
                        DecryptButton.Text = "解密";
                        AboutButton.Text = "关于...";
                        label4.Text = "密码必须为8位";
                        label1.Text = "文件路径";
                        label2.Text = "保存路径";
                        label3.Text = "密码";
                        notifyIcon1.Text = "文件加密器";
                        notifyIcon1.BalloonTipText = "点我打开窗口";
                        notifyIcon1.BalloonTipTitle = "我在这里";
                        NavWebsite.Text = "访问更新页";
                        LanItem.Text = "语言";
                        break;

                    case (1):
                        Text = "File Encrypter";
                        Title.Text = "File Encrypter " + version + " by Stehsaer x64";
                        EncryptButton.Text = "Encrypt";
                        DecryptButton.Text = "Decrypt";
                        AboutButton.Text = "About";
                        label4.Text = "8 characters are needed";
                        label1.Text = "Source File";
                        label2.Text = "Save File";
                        label3.Text = "Password";
                        notifyIcon1.Text = "File Encrypter";
                        notifyIcon1.BalloonTipText = "Click me to recover";
                        notifyIcon1.BalloonTipTitle = "I'm here";
                        NavWebsite.Text = "Visit release page";
                        LanItem.Text = "Language";
                        break;
                }
            }
            else
            {
                switch (language)
                {
                    case (0):
                        Text = "文件加密器";
                        Title.Text = "文件加密器 " + version + " by Stehsaer x86";
                        EncryptButton.Text = "加密";
                        DecryptButton.Text = "解密";
                        AboutButton.Text = "关于...";
                        label4.Text = "密码必须为8位";
                        label1.Text = "文件路径";
                        label2.Text = "保存路径";
                        label3.Text = "密码";
                        notifyIcon1.Text = "文件加密器";
                        notifyIcon1.BalloonTipText = "点我打开窗口";
                        notifyIcon1.BalloonTipTitle = "我在这里";
                        NavWebsite.Text = "访问更新页";
                        LanItem.Text = "语言";
                        break;

                    case (1):
                        Text = "File Encrypter";
                        Title.Text = "File Encrypter " + version + " by Stehsaer x86";
                        EncryptButton.Text = "Encrypt";
                        DecryptButton.Text = "Decrypt";
                        AboutButton.Text = "About";
                        label4.Text = "8 characters are needed";
                        label1.Text = "Source File";
                        label2.Text = "Save File";
                        label3.Text = "Password";
                        notifyIcon1.Text = "File Encrypter";
                        notifyIcon1.BalloonTipText = "Click me to recover";
                        notifyIcon1.BalloonTipTitle = "I'm here";
                        NavWebsite.Text = "Visit release page";
                        LanItem.Text = "Language";
                        break;
                }
            }
        }

        private void Zh_cn_item_Click(object sender, EventArgs e)
        {
            language = 0;
            zh_cn_item.Checked = true;
            en_us_item.Checked = false;
            ChangeLanguage();
        }

        private void En_us_item_Click(object sender, EventArgs e)
        {
            language = 1;
            zh_cn_item.Checked = !true;
            en_us_item.Checked = !false;
            ChangeLanguage();
        }

        private void NavWebsite_Click(object sender, EventArgs e)
        {
            Process.Start(website);
        }

        private void PictureBox1_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, new Rectangle(0, 0, pictureBox1.Width, pictureBox1.Height),
                maincolor, 1, ButtonBorderStyle.Solid,
                maincolor, 1, ButtonBorderStyle.Solid,
                maincolor, 1, ButtonBorderStyle.Solid,
                maincolor, 1, ButtonBorderStyle.Solid);
        }

        private void PictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                SettingsStrip.Show(MousePosition);
            }
        }
    }
}