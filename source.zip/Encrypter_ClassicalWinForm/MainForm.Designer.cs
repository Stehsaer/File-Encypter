﻿namespace Encrypter_ClassicalWinForm
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ProgressLabel = new System.Windows.Forms.Label();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.EncryptButton = new System.Windows.Forms.Button();
            this.DecryptButton = new System.Windows.Forms.Button();
            this.EncB = new System.ComponentModel.BackgroundWorker();
            this.DecB = new System.ComponentModel.BackgroundWorker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.progressbar = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.AboutButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.PasswordBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SaveFileSelect = new System.Windows.Forms.Button();
            this.SaveFileText = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.OpenFileSelect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.OpenFileText = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Title = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.saveFile = new System.Windows.Forms.SaveFileDialog();
            this.SettingsStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LanItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zh_cn_item = new System.Windows.Forms.ToolStripMenuItem();
            this.en_us_item = new System.Windows.Forms.ToolStripMenuItem();
            this.NavWebsite = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SettingsStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // ProgressLabel
            // 
            this.ProgressLabel.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ProgressLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ProgressLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ProgressLabel.Location = new System.Drawing.Point(0, 0);
            this.ProgressLabel.Margin = new System.Windows.Forms.Padding(10, 0, 3, 0);
            this.ProgressLabel.Name = "ProgressLabel";
            this.ProgressLabel.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.ProgressLabel.Size = new System.Drawing.Size(395, 24);
            this.ProgressLabel.TabIndex = 1;
            this.ProgressLabel.Text = "label1";
            this.ProgressLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // openFile
            // 
            this.openFile.RestoreDirectory = true;
            // 
            // EncryptButton
            // 
            this.EncryptButton.AutoSize = true;
            this.EncryptButton.BackColor = System.Drawing.Color.PaleTurquoise;
            this.EncryptButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.EncryptButton.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.EncryptButton.FlatAppearance.BorderSize = 2;
            this.EncryptButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EncryptButton.Location = new System.Drawing.Point(39, 130);
            this.EncryptButton.Name = "EncryptButton";
            this.EncryptButton.Size = new System.Drawing.Size(74, 33);
            this.EncryptButton.TabIndex = 2;
            this.EncryptButton.Text = "加密";
            this.EncryptButton.UseVisualStyleBackColor = false;
            this.EncryptButton.Click += new System.EventHandler(this.EncryptButton_Click);
            // 
            // DecryptButton
            // 
            this.DecryptButton.BackColor = System.Drawing.Color.Moccasin;
            this.DecryptButton.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.DecryptButton.FlatAppearance.BorderSize = 2;
            this.DecryptButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DecryptButton.Location = new System.Drawing.Point(132, 130);
            this.DecryptButton.Name = "DecryptButton";
            this.DecryptButton.Size = new System.Drawing.Size(74, 33);
            this.DecryptButton.TabIndex = 3;
            this.DecryptButton.Text = "解密";
            this.DecryptButton.UseVisualStyleBackColor = false;
            this.DecryptButton.Click += new System.EventHandler(this.DecyrptButton_Click);
            // 
            // EncB
            // 
            this.EncB.DoWork += new System.ComponentModel.DoWorkEventHandler(this.EncB_DoWork);
            this.EncB.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.EncB_RunWorkerCompleted);
            // 
            // DecB
            // 
            this.DecB.DoWork += new System.ComponentModel.DoWorkEventHandler(this.DecB_DoWork);
            this.DecB.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.DecB_RunWorkerCompleted);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.progressbar);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 174);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(395, 5);
            this.panel1.TabIndex = 5;
            // 
            // progressbar
            // 
            this.progressbar.BackColor = System.Drawing.Color.CornflowerBlue;
            this.progressbar.Dock = System.Windows.Forms.DockStyle.Left;
            this.progressbar.Location = new System.Drawing.Point(0, 0);
            this.progressbar.Name = "progressbar";
            this.progressbar.Size = new System.Drawing.Size(11, 5);
            this.progressbar.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel2.Controls.Add(this.ProgressLabel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 179);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(395, 24);
            this.panel2.TabIndex = 6;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.AboutButton);
            this.panel3.Controls.Add(this.EncryptButton);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Controls.Add(this.PasswordBox);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.SaveFileSelect);
            this.panel3.Controls.Add(this.DecryptButton);
            this.panel3.Controls.Add(this.SaveFileText);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.OpenFileSelect);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.OpenFileText);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 31);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(395, 203);
            this.panel3.TabIndex = 7;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel3_Paint);
            // 
            // AboutButton
            // 
            this.AboutButton.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.AboutButton.FlatAppearance.BorderColor = System.Drawing.Color.YellowGreen;
            this.AboutButton.FlatAppearance.BorderSize = 2;
            this.AboutButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AboutButton.Location = new System.Drawing.Point(218, 130);
            this.AboutButton.Name = "AboutButton";
            this.AboutButton.Size = new System.Drawing.Size(74, 33);
            this.AboutButton.TabIndex = 10;
            this.AboutButton.Text = "关于...";
            this.AboutButton.UseVisualStyleBackColor = false;
            this.AboutButton.Click += new System.EventHandler(this.AboutButton_Click);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(261, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 44);
            this.label4.TabIndex = 8;
            this.label4.Text = "密码必须为8位";
            // 
            // PasswordBox
            // 
            this.PasswordBox.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.PasswordBox.Location = new System.Drawing.Point(132, 80);
            this.PasswordBox.MaxLength = 8;
            this.PasswordBox.Name = "PasswordBox";
            this.PasswordBox.Size = new System.Drawing.Size(114, 23);
            this.PasswordBox.TabIndex = 7;
            this.PasswordBox.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "密码";
            this.label3.MouseEnter += new System.EventHandler(this.Label3_MouseEnter);
            this.label3.MouseLeave += new System.EventHandler(this.Label3_MouseLeave);
            // 
            // SaveFileSelect
            // 
            this.SaveFileSelect.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SaveFileSelect.BackgroundImage")));
            this.SaveFileSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.SaveFileSelect.FlatAppearance.BorderSize = 0;
            this.SaveFileSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveFileSelect.Location = new System.Drawing.Point(271, 45);
            this.SaveFileSelect.Name = "SaveFileSelect";
            this.SaveFileSelect.Size = new System.Drawing.Size(28, 28);
            this.SaveFileSelect.TabIndex = 5;
            this.SaveFileSelect.UseVisualStyleBackColor = true;
            this.SaveFileSelect.Click += new System.EventHandler(this.SaveFileSelect_Click);
            // 
            // SaveFileText
            // 
            this.SaveFileText.Location = new System.Drawing.Point(132, 48);
            this.SaveFileText.Name = "SaveFileText";
            this.SaveFileText.Size = new System.Drawing.Size(114, 23);
            this.SaveFileText.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "保存路径";
            // 
            // OpenFileSelect
            // 
            this.OpenFileSelect.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OpenFileSelect.BackgroundImage")));
            this.OpenFileSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.OpenFileSelect.FlatAppearance.BorderSize = 0;
            this.OpenFileSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OpenFileSelect.Location = new System.Drawing.Point(271, 12);
            this.OpenFileSelect.Name = "OpenFileSelect";
            this.OpenFileSelect.Size = new System.Drawing.Size(28, 28);
            this.OpenFileSelect.TabIndex = 2;
            this.OpenFileSelect.UseVisualStyleBackColor = true;
            this.OpenFileSelect.Click += new System.EventHandler(this.OpenFileSelect_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "文件路径";
            // 
            // OpenFileText
            // 
            this.OpenFileText.AllowDrop = true;
            this.OpenFileText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OpenFileText.Location = new System.Drawing.Point(132, 16);
            this.OpenFileText.Name = "OpenFileText";
            this.OpenFileText.Size = new System.Drawing.Size(114, 23);
            this.OpenFileText.TabIndex = 1;
            this.OpenFileText.DragDrop += new System.Windows.Forms.DragEventHandler(this.OpenFileText_DragDrop);
            this.OpenFileText.DragEnter += new System.Windows.Forms.DragEventHandler(this.OpenFileText_DragEnter);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel4.Controls.Add(this.Title);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(395, 31);
            this.panel4.TabIndex = 9;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel4_Paint);
            this.panel4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel4_MouseDown);
            this.panel4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel4_MouseUp);
            // 
            // Title
            // 
            this.Title.Dock = System.Windows.Forms.DockStyle.Left;
            this.Title.Location = new System.Drawing.Point(0, 0);
            this.Title.Name = "Title";
            this.Title.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.Title.Size = new System.Drawing.Size(322, 31);
            this.Title.TabIndex = 12;
            this.Title.Text = "Title";
            this.Title.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Title.Paint += new System.Windows.Forms.PaintEventHandler(this.Label5_Paint);
            this.Title.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel4_MouseDown);
            this.Title.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel4_MouseUp);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button3);
            this.panel5.Controls.Add(this.button4);
            this.panel5.Location = new System.Drawing.Point(328, 8);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(24, 12);
            this.panel5.TabIndex = 11;
            // 
            // button3
            // 
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(0, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(24, 12);
            this.button3.TabIndex = 1;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button2_Click);
            // 
            // button4
            // 
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(0, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(24, 12);
            this.button4.TabIndex = 0;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button2);
            this.panel6.Controls.Add(this.button1);
            this.panel6.Location = new System.Drawing.Point(358, 10);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(24, 12);
            this.panel6.TabIndex = 10;
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(24, 12);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button3_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(24, 12);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.notifyIcon1.BalloonTipText = "点我打开窗口";
            this.notifyIcon1.BalloonTipTitle = "我在这里";
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "文件加密器";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.BalloonTipClicked += new System.EventHandler(this.NotifyIcon1_BalloonTipClicked);
            this.notifyIcon1.Click += new System.EventHandler(this.NotifyIcon1_Click);
            // 
            // SettingsStrip
            // 
            this.SettingsStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LanItem,
            this.NavWebsite});
            this.SettingsStrip.Name = "SettingsStrip";
            this.SettingsStrip.Size = new System.Drawing.Size(137, 48);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(316, 131);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(36, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.PictureBox1_Paint);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PictureBox1_MouseDown);
            // 
            // LanItem
            // 
            this.LanItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zh_cn_item,
            this.en_us_item});
            this.LanItem.Name = "LanItem";
            this.LanItem.Size = new System.Drawing.Size(180, 22);
            this.LanItem.Text = "语言";
            // 
            // zh_cn_item
            // 
            this.zh_cn_item.CheckOnClick = true;
            this.zh_cn_item.Name = "zh_cn_item";
            this.zh_cn_item.Size = new System.Drawing.Size(180, 22);
            this.zh_cn_item.Text = "简体中文";
            this.zh_cn_item.Click += new System.EventHandler(this.Zh_cn_item_Click);
            // 
            // en_us_item
            // 
            this.en_us_item.CheckOnClick = true;
            this.en_us_item.Name = "en_us_item";
            this.en_us_item.Size = new System.Drawing.Size(180, 22);
            this.en_us_item.Text = "English";
            this.en_us_item.Click += new System.EventHandler(this.En_us_item_Click);
            // 
            // NavWebsite
            // 
            this.NavWebsite.Name = "NavWebsite";
            this.NavWebsite.Size = new System.Drawing.Size(180, 22);
            this.NavWebsite.Text = "访问更新页";
            this.NavWebsite.Click += new System.EventHandler(this.NavWebsite_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.button2;
            this.ClientSize = new System.Drawing.Size(395, 234);
            this.ControlBox = false;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "文件加密器";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.SettingsStrip.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label ProgressLabel;
        private System.Windows.Forms.OpenFileDialog openFile;
        private System.Windows.Forms.Button EncryptButton;
        private System.Windows.Forms.Button DecryptButton;
        private System.ComponentModel.BackgroundWorker EncB;
        private System.ComponentModel.BackgroundWorker DecB;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel progressbar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox PasswordBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button SaveFileSelect;
        private System.Windows.Forms.TextBox SaveFileText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button OpenFileSelect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox OpenFileText;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Button AboutButton;
        private System.Windows.Forms.SaveFileDialog saveFile;
        private System.Windows.Forms.ContextMenuStrip SettingsStrip;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem LanItem;
        private System.Windows.Forms.ToolStripMenuItem zh_cn_item;
        private System.Windows.Forms.ToolStripMenuItem en_us_item;
        private System.Windows.Forms.ToolStripMenuItem NavWebsite;
    }
}

