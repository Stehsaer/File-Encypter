﻿namespace Encrypter
{
    class getLanguage
    {
        public enum Language
        {
            zh_cn,
            en_us
        }

        public static string[][] data = new string[][]
        {
            new string[]{"中文","提示","错误","准备就绪","读取文件中 ","文件重排序中 ","加密文件中   ","解密文件中   ","写入文件中   ","合并安全信息中   ","哈希计算中 ","拆分信息中   ","原有文件|*","所有文件|*.*","加密文件|*.enc","大小超过 2GiB 的文件不受支持","密码位数必须为8","文件不存在","缺少权限访问文件 (System.UnauthorizedAccessException)","源文件已损坏","密码错误","这个后缀感觉不是用来解密的啊","一切程序完成","不支持多文件加/解密","不支持","关于本软件","本软件由 @Stehsaer 制作。","联系方式：Email：","有bug记得联系作者鸭~ 在GitHub上报告问题吧！"},
            new string[]{ "English", "Information","Error","Waiting for start", "Reading source file ", "Sorting source file... ","Encrypting Data ","Decrypting Data ","Writing File ","Merging data ","Computing Hash ","Seperating data ","Original File Extension|*.*","All Files|*.*","Encrypter Extension|*.enc","Encrypting or decrypting file larger than 2 GiB isn't supported","There must be 8 digits or letters in the password","","You don't have access to edit the file","The file has been damaged","Invalid Password","It doesn't seems that the extension is for encrypted files","All requested processes are done","Multi-file encrypting or decrypting is not supported in beta version","Not supported action","About the software","The software is made by @Stehsaer.","Contact me:Email:","Contact me or report an issue on Github if there is any bugs, thank you!"  }
        };

        public static string getString(Language targetLanguageType ,int index )
        {
            return data[(int)targetLanguageType][index];
        }

        public static string getString(Language targetLanguageType, string str, Language sourceLanguage)
        {
            for(int i=0;i<data[(int)sourceLanguage].Length;i++)
            {
                if(data[(int)sourceLanguage][i]==str)
                {
                    return data[(int)targetLanguageType][i];
                }
            }
            return null;
        }
    }
}
